package test;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.AmazonHomePage;
import pages.AmazonProductPage;
import pages.AmazonSearchResultsPage;

public class AmazonTest {

    WebDriver driver;
    AmazonHomePage homePage;
    AmazonSearchResultsPage resultsPage;
    AmazonProductPage productPage;

    @BeforeClass
    void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.get("https://www.amazon.com/");

        homePage = new AmazonHomePage(driver);
        resultsPage = new AmazonSearchResultsPage(driver);
        productPage = new AmazonProductPage(driver);
    }

    @Test(priority = 1)
    void searchProduct() {
        homePage.handleContinueShopping();
        homePage.searchProduct("laptop");
    }

    @Test(priority = 2)
    void selectFirstProduct() {
        resultsPage.clickFirstProduct();
    }

    @Test(priority = 3)
    void validateProductDetails() {
        Assert.assertTrue(
                productPage.isProductDetailsVisible(),
                "Product details not available");
    }

    @Test(priority = 4)
    void captureScreenshot() throws Exception {
        productPage.takeScreenshot();
        driver.quit();
    }
}

