package pages;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AmazonHomePage {

    WebDriver driver;
    WebDriverWait wait;

    By continueShoppingBtn =
            By.xpath("//button[contains(text(),'Continue shopping')]");

    By searchBox = By.id("twotabsearchtextbox");

    public AmazonHomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void handleContinueShopping() {
        if (isElementVisible(continueShoppingBtn)) {
            wait.until(ExpectedConditions.elementToBeClickable(continueShoppingBtn)).click();
        }
    }

    public void searchProduct(String product) {
        driver.findElement(searchBox).sendKeys(product + "\n");
    }

    private boolean isElementVisible(By locator) {
        List<WebElement> elements = driver.findElements(locator);
        return !elements.isEmpty() && elements.get(0).isDisplayed();
    }
}
