package pages;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class AmazonProductPage {

    WebDriver driver;

    By buyingOptionsBtn =
            By.xpath("//a[contains(text(),'See All Buying Options')]");

    public AmazonProductPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isProductDetailsVisible() {
        return !driver.findElements(buyingOptionsBtn).isEmpty()
                && driver.findElements(buyingOptionsBtn).get(0).isDisplayed();
    }

    public void takeScreenshot() throws IOException {
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

        String path = System.getProperty("user.dir")
                + "/Screenshot/detailScreenshot.png";

        File dest = new File(path);
        dest.getParentFile().mkdirs();
        Files.copy(src.toPath(), dest.toPath());
    }
}
