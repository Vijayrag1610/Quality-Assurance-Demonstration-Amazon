# Amazon Automation Framework

## Overview
This is a Selenium automation framework built using Java, TestNG, and Page Object Model (POM).
It automates a basic Amazon user flow: search a product, select the first result,
validate product page, and capture a screenshot.

## Tech Stack
- Java
- Selenium WebDriver
- TestNG
- Maven
- ChromeDriver

## Project Structure
src/test/java
 ├── pages
 │   ├── AmazonHomePage.java
 │   ├── AmazonSearchResultsPage.java
 │   └── AmazonProductPage.java
 │
 └── tests
     └── AmazonTest.java

Screenshot/
 └── detailScreenshot.png

## Test Flow
1. Open Amazon
2. Search for a product
3. Click first product from results
4. Validate product details
5. Capture screenshot

## How to Run
- Import project as Maven Project
- Run AmazonTest.java as TestNG Test
- Or run: mvn test

## Screenshot
Saved under /Screenshot/detailScreenshot.png
(takes a bit of time to appear)

## Design Pattern
- Page Object Model (POM)
- Explicit waits used

## Author
Vijayraghavendra
Selenium | Java | TestNG